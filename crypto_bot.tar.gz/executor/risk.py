import os
"""
風險管理模組
完整混合策略：固定止損、移動止損、分批出場、時間止損、技術出場（鐵三角）
"""
from typing import Dict, Optional, Tuple, Set
from datetime import datetime
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from executor.position import Position


class RiskManager:
    """風險管理器 - 完整混合策略"""
    
    def __init__(self, config: Dict):
        """
        初始化風險管理器
        
        Args:
            config: 配置字典
        """
        self.config = config.get('trading', {})
        self.scaling_config = config.get('scaling_out', {})
        
        # 固定止損
        self.stop_loss_usdt = self.config.get('stop_loss', 5)
        
        # 移動止損
        self.trailing_stop_enabled = self.config.get('trailing_stop_enabled', True)
        self.trailing_trigger_pnl = self.config.get('trailing_trigger_pnl', 10)
        self.trailing_retention = self.config.get('trailing_retention_ratio', 0.67)
        
        # 技術出場 - 鐵三角組合 (取代舊版時間止損)
        self.technical_exit_enabled = self.config.get('technical_exit_enabled', True)
        self.price_deviation_threshold = self.config.get('price_deviation_threshold', 10.0)
        self.peak_drawdown_threshold = self.config.get('peak_drawdown_threshold', 5.0)
        self.time_limit_minutes = self.config.get('time_limit_minutes', 20)
        self.min_profit_usdt = self.config.get('min_profit_usdt', 3.0)
        
        # 成交量指標 (已棄用)
        self.technical_volume_ratio = self.config.get('technical_exit_volume_ratio', 0.0)
    
    def check_exit(self, position: Position, current_price: float, 
                   volume_ratio: float = 1.0, ma_price: Optional[float] = None) -> Optional[Dict]:
        """
        檢查出場條件（依優先級）
        
        優先級:
        1. 固定止損 (最高)
        2. 移動止損
        3. 技術出場 (鐵三角) - 僅在 PnL < 50% 時啟用
        4. 全數止盈 (200%)
        5. 分批出場
        
        注意：舊版時間止損已移除，由鐵三角中的「時間 + 收益」取代
        """
        # 計算 PnL
        pnl = position.get_pnl(current_price)
        pnl_percent = position.get_pnl_percent(current_price)
        holding_minutes = position.get_holding_minutes()
        
        # 1. 固定止損 (最高優先級)
        if pnl <= -self.stop_loss_usdt:
            return {
                'action': 'EXIT',
                'type': 'STOP_LOSS',
                'reason': f'固定止損 (PnL: {pnl:.2f} USDT)',
                'quantity_ratio': 1.0,
                'priority': 1
            }
        
        # 2. 【新增】全數止盈 60%
        if pnl_percent >= 60:
            return {
                'action': 'EXIT',
                'type': 'FULL_EXIT',
                'reason': f'全數止盈 (收益率 {pnl_percent:.1f}%)',
                'quantity_ratio': 1.0,
                'priority': 2
            }
        
        # 3. 移動止損 (收益率版本)
        if self.trailing_stop_enabled:
            trailing = self._check_trailing_stop(position, current_price, pnl, pnl_percent)
            if trailing:
                return trailing
        
        # 3. 技術出場 (鐵三角) - 僅在 PnL < 50% 時啟用
        if self.technical_exit_enabled and pnl_percent < 50:
            # 3.1 價格偏離度 (需要 MA)
            if ma_price is not None and ma_price > 0:
                deviation_exit = self._check_price_deviation(position, current_price, ma_price)
                if deviation_exit:
                    return deviation_exit
            
            # 3.2 高點回撤
            drawdown_exit = self._check_peak_drawdown(position, current_price)
            if drawdown_exit:
                return drawdown_exit
            
            # 3.3 時間 + 收益組合
            time_exit = self._check_time_profit(position, current_price, pnl, holding_minutes)
            if time_exit:
                return time_exit
        
        # 4. 全數止盈 (200%)
        if pnl_percent >= 200:
            return {
                'action': 'EXIT',
                'type': 'FULL_EXIT',
                'reason': f'全數止盈 (收益率 {pnl_percent:.1f}%)',
                'quantity_ratio': 1.0,
                'priority': 4
            }
        
        # 4. 【停用】分批出場 - 用戶要求停用
        # scaling = self._check_scaling_out(position, current_price, pnl_percent)
        # if scaling:
        #     return scaling
        
        return None
    
    def _check_price_deviation(self, position: Position, current_price: float, ma_price: float) -> Optional[Dict]:
        """檢查價格偏離度 (鐵三角 1 號)"""
        if ma_price <= 0:
            return None
            
        deviation = (current_price - ma_price) / ma_price * 100
        
        # 只檢查正向偏離（漲太多）
        if deviation > self.price_deviation_threshold:
            return {
                'action': 'EXIT',
                'type': 'TECHNICAL_EXIT',
                'reason': f'價格偏離 ({deviation:.1f}% > {self.price_deviation_threshold}%)',
                'quantity_ratio': 1.0,
                'priority': 3
            }
        return None

    def _check_peak_drawdown(self, position: Position, current_price: float) -> Optional[Dict]:
        """檢查高點回撤 (鐵三角 2 號)"""
        if position.side == 'LONG':
            highest_price = position.highest_price
            if highest_price > 0:
                drawdown = (highest_price - current_price) / highest_price * 100
                if drawdown > self.peak_drawdown_threshold:
                    return {
                        'action': 'EXIT',
                        'type': 'TECHNICAL_EXIT',
                        'reason': f'高點回撤 ({drawdown:.1f}% > {self.peak_drawdown_threshold}%)',
                        'quantity_ratio': 1.0,
                        'priority': 3
                    }
        return None

    def _check_time_profit(self, position: Position, current_price: float, 
                           pnl: float, holding_minutes: int) -> Optional[Dict]:
        """檢查時間 + 收益組合 (鐵三角 3 號)"""
        if holding_minutes >= self.time_limit_minutes and pnl < self.min_profit_usdt:
            return {
                'action': 'EXIT',
                'type': 'TECHNICAL_EXIT',
                'reason': f'時間 + 收益 ({holding_minutes}分, PnL: {pnl:.2f} USDT)',
                'quantity_ratio': 1.0,
                'priority': 3
            }
        return None
    
    def _check_trailing_stop(self, position: Position, current_price: float, 
                             pnl: float, pnl_percent: float) -> Optional[Dict]:
        """收益率版本移動止損 - 從最高收益率回撤33%"""
        # 1. 檢查是否達到啟動門檻 (10%)
        if pnl_percent < 10.0:
            return None
        
        # 2. 檢查是否從最高收益率回撤 33% (保留 67%)
        highest = position.highest_pnl_percent
        retention_ratio = 0.67  # 保留67%利潤 = 回撤33%
        
        if highest > 0:
            # 計算回撤閾值
            drawdown_threshold = highest * retention_ratio
            
            # 如果當前收益率跌破閾值，觸發移動止損
            if pnl_percent < drawdown_threshold:
                drawdown_percent = highest - pnl_percent
                return {
                    'action': 'EXIT',
                    'type': 'TRAILING_STOP',
                    'reason': f'移動止損 (最高{highest:.1f}% → 當前{pnl_percent:.1f}%, 回撤 {drawdown_percent:.1f}%)',
                    'quantity_ratio': 1.0,
                    'priority': 2
                }
        
        return None
    
    def _check_scaling_out(self, position: Position, current_price: float,
                           pnl_percent: float) -> Optional[Dict]:
        """檢查分批出場"""
        exited_levels: Set[int] = set()
        for exit_record in position.partial_exits:
            exited_pnl = exit_record.get('exited_pnl_percent', 0)
            if exited_pnl >= 200:
                exited_levels.add(200)
            elif exited_pnl >= 150:
                exited_levels.add(150)
            elif exited_pnl >= 100:
                exited_levels.add(100)
            elif exited_pnl >= 50:
                exited_levels.add(50)
        
        thresholds = [
            (50, '50%'),
            (100, '100%'),
            (150, '150%'),
        ]
        
        for threshold, label in thresholds:
            if pnl_percent >= threshold and threshold not in exited_levels:
                return {
                    'action': 'REDUCE',
                    'type': 'SCALING_OUT',
                    'reason': f'分批出場 ({label} 收益)',
                    'quantity_ratio': 0.25,
                    'priority': 5,
                    'target_level': threshold
                }
        
        return None
